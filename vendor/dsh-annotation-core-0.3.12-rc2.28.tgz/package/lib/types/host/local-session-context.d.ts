import type { Context } from '@deepseek-ai/cordis';
import { z } from 'zod';
import type { UpstreamHost } from './upstream.ts';
import type { SessionExtensionData } from './session-extension-data.ts';
declare const entrySchema: z.ZodObject<{
    eventId: z.ZodString;
    role: z.ZodString;
    text: z.ZodString;
}, z.core.$strip>;
type Entry = z.infer<typeof entrySchema>;
export interface LocalSessionSource {
    workspaces?(): Promise<{
        id: string;
        title: string;
    }[]>;
    list(workspaceId?: string): Promise<{
        id: string;
        title: string;
    }[]>;
    read(sessionId: string): Promise<{
        title: string;
        entries: Entry[];
    }>;
}
/** Immutable source material and grants are session extensions, not an adapter database. */
export declare class LocalSessionContext implements UpstreamHost {
    private readonly data;
    private readonly source;
    readonly protocolVersion: 1;
    private captureTail;
    private executions;
    constructor(data: SessionExtensionData, source: LocalSessionSource);
    directory(workspaceId?: string, after?: string): Promise<{
        items: {
            id: string;
            title: string;
        }[];
        nextCursor: string | null;
    }>;
    preview(id: string, cursor?: string, selection?: {
        sourceVersionId: string;
        sourceAnchorId: string;
    }): Promise<{
        logicalSessionId: string;
        nativeSessionId: string;
        title: string;
        sourceVersionId: string;
        items: {
            text: string;
            offset: number;
            complete: boolean;
            eventId: string;
            role: string;
        }[];
        hasMore: boolean;
        nextCursor: string | null;
        capture: {
            sourceSessionId: string;
            anchorId: string;
            messageId: string;
            role: string;
            occurrence: number;
            selectedText: string;
        };
    }>;
    private record;
    capture(input: Parameters<UpstreamHost['capture']>[0]): Promise<{
        referenceId: string;
        sourceNativeSessionId: string;
        targetNativeSessionId: string;
        sourceTitle: string;
        sourceVersionId: string;
        cutoffEventId: string;
        sourceAnchorId: string;
        selectedText: string;
        requestDigest: string;
        state: "pending" | "sent" | "revoked";
        targetMessageId: string | null;
        entries: {
            eventId: string;
            role: string;
            text: string;
        }[];
        turnStart: number;
    }>;
    private captureSerial;
    inspect(target: string, id: string): Promise<{
        referenceId: string;
        sourceNativeSessionId: string;
        targetNativeSessionId: string;
        sourceTitle: string;
        sourceVersionId: string;
        cutoffEventId: string;
        sourceAnchorId: string;
        selectedText: string;
        requestDigest: string;
        state: "pending" | "sent" | "revoked";
        targetMessageId: string | null;
        entries: {
            eventId: string;
            role: string;
            text: string;
        }[];
        turnStart: number;
    }>;
    status(target: string, id: string): Promise<{
        referenceId: string;
        state: "pending" | "sent" | "revoked";
    }>;
    describe(target: string, id: string): Promise<{
        record: {
            referenceId: string;
            sourceNativeSessionId: string;
            targetNativeSessionId: string;
            sourceTitle: string;
            sourceVersionId: string;
            cutoffEventId: string;
            sourceAnchorId: string;
            selectedText: string;
            requestDigest: string;
            state: "pending" | "sent" | "revoked";
            targetMessageId: string | null;
            entries: {
                eventId: string;
                role: string;
                text: string;
            }[];
            turnStart: number;
        };
        sourceNativeSessionId: string;
    }>;
    bind(target: string, id: string, messageId: string | null): Promise<{
        state: string;
        targetMessageId: string | null;
        referenceId: string;
        sourceNativeSessionId: string;
        targetNativeSessionId: string;
        sourceTitle: string;
        sourceVersionId: string;
        cutoffEventId: string;
        sourceAnchorId: string;
        selectedText: string;
        requestDigest: string;
        entries: {
            eventId: string;
            role: string;
            text: string;
        }[];
        turnStart: number;
    }>;
    read(input: Parameters<UpstreamHost['read']>[0]): Promise<{
        referenceId: string;
        sourceVersionId: string;
        cutoffEventId: string;
        items: {
            eventId: string;
            role: string;
            text: string;
            offset: number;
            complete: boolean;
        }[];
        nextCursor: string | null;
        hasMore: boolean;
        selectedTurn: {
            complete: boolean;
        };
    }>;
    endExecution(target: string, executionId: string): Promise<void>;
}
/** DSH's public query service supplies cold and live history; no filesystem paths are read. */
export declare function localSessionSource(ctx: Context): LocalSessionSource;
export {};
//# sourceMappingURL=local-session-context.d.ts.map