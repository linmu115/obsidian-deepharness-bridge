# Changelog

## 0.3.12-rc2.1 — 2026-09-13

- Add fixed cross-session references, a shared target picker and bounded upstream read/search tools.
- Persist successful target bindings and retry reference revocation without copying source histories.
- See docs/changes/2026-09-13-cross-session-upstream.md for pairing and validation.


## 0.3.11-rc2.2 — DSH 0.1.5-rc.2 (2026-09-12)

110 tests passed. RC2 ordered attachment admission, durable message snapshots, and additive instance IDs in logical reference DTOs. Existing unscoped request/commit digests are unchanged.


## 0.3.10-dev.0 - Unreleased

- Settle submitted references only after one saved native or external acceptance receipt covers the user message and annotation context. Saved-only inputs remain unconfirmed; retries do not resend them.
- Preserve pre-step request-series metadata, release the admission lock before waiting, and retain drafts when executor input admission fails.
- Prevent late backlinks or stale cleanup receipts from restoring a deleted relation.
- Add scoped `dsh_reference_list` and `dsh_reference_read` tools, including inherited snapshot reads without new backlinks.

Requires the paired M5 Harness build; the unmodified RC1 registry release does not provide its receipt and admission APIs.

## 0.3.9 - 2026-09-07

- Confirm pending relation deletions with their persisted session, set and reference identity. Existing failed discard jobs recover from their matching tombstones after restart without a storage migration.
- Preserve ordinary capture cancellation and keep mismatched or unacknowledged deletions durable for retry.

## 0.3.8 - Unreleased

- Add an explicit `notifySource: false` rollback option for losing cross-consumer claims, preserving local revision/idempotence without scheduling a global reference discard.

- Read pending summaries, individual submissions, and durable retry lanes without
  copying unrelated sent-reference history. Public read results remain detached;
  serialized writes, revision checks, and durable outbox settlement are unchanged.
- Share one DOM observer and anchor index per conversation root. Coalesce mutation
  deliveries, update affected subtrees and keys, and correctly release suppression
  after duplicate subscriptions, rekeys, removals, and remounts.
- Add behavior and operation-count regressions at 50/200/500 conversation rows and
  0/100/1000 historical sets.

No data migration is required. Existing consumers retain their default discard behavior. The on-disk aggregate
format and logical reference, event, and deletion identities remain unchanged.

## 0.3.7 - 2026-09-04

- Target the DSH 0.1.2-rc.1 session contract without retaining an older
  Harness compatibility branch.
- Replace removed `Session.events` reads with immutable
  `Session.snapshotEvents()` snapshots during submission settlement and
  startup reconciliation.
- Preserve the RC1-branded `SessionSeq` from the observed user event through
  `sourceEventSeqs`, instead of narrowing it to an unbranded number.
- Pin the RC1 development packages and Zod 4.4.3 so the suite is compiled
  against one host type identity.

The Annotation Core Host API, immediate-local/background-remote deletion
settlement, annotation projection visibility, and prompt admission semantics
are unchanged.

## 0.3.6 - 2026-09-01

- Treat `@deepseek-ai/schemastery` as a DSH host capability instead of a
  plugin-owned runtime dependency.
- Declare an open optional peer so experimental Harness combinations remain
  selectable without making pnpm install a second core package tree.
- Keep Alpha2 `3.18.2` as a development-only compiler and test dependency.

Focused verification: package manifest contract, typecheck, build and package
dry run.

## 0.3.5 - 2026-08-31

- Add stable `logicalSessionId` and `logicalAnchorId` fields to annotation links while retaining native session and anchor fallbacks.
- Resolve current Launcher projections through Session Maintenance before opening or deleting a reference.
- Preserve the existing immediate local delete behavior and idempotent background Core cleanup.
- Base this release on the verified Alpha.2 `0.3.4` tree; no DSH peer range is hard locked.

Focused verification: `tests/answer-link.test.tsx`, typecheck and build.
