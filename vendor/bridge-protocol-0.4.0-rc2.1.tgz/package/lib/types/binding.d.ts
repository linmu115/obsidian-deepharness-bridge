import { z } from 'zod';
export declare const DISCOVERY_PROTOCOL_VERSION: 1;
export declare const VAULT_BINDING_PROTOCOL_VERSION: 1;
export declare const DSH_IDENTITY_PATH = "/obsidian-bridge/identity";
export declare const VAULT_IDENTITY_PATH = "/discovery/v1/identity";
export declare const VAULT_BINDING_PATH = "/control/v1/binding";
export declare const BINDING_CAPABILITY = "vault-instance-binding-v1";
export declare const discoveryOriginSchema: z.ZodString;
export declare const bindingTargetSchema: z.ZodObject<{
    instanceId: z.ZodString;
    profileId: z.ZodString;
}, z.core.$strict>;
export type BindingTarget = z.infer<typeof bindingTargetSchema>;
export declare const vaultBindingSnapshotSchema: z.ZodObject<{
    bindingProtocolVersion: z.ZodLiteral<1>;
    vaultId: z.ZodString;
    revision: z.ZodNumber;
    target: z.ZodNullable<z.ZodObject<{
        instanceId: z.ZodString;
        profileId: z.ZodString;
    }, z.core.$strict>>;
    updatedAt: z.ZodNumber;
    lastOperationId: z.ZodOptional<z.ZodString>;
}, z.core.$strict>;
export type VaultBindingSnapshot = z.infer<typeof vaultBindingSnapshotSchema>;
export declare const dshInstanceIdentitySchema: z.ZodObject<{
    kind: z.ZodLiteral<"dsh">;
    instanceId: z.ZodString;
    profileId: z.ZodString;
    discoveryProtocolVersion: z.ZodLiteral<1>;
    bootId: z.ZodString;
    publisherId: z.ZodString;
    displayName: z.ZodString;
    origin: z.ZodString;
    capabilities: z.ZodArray<z.ZodString>;
}, z.core.$strict>;
export declare const vaultIdentitySchema: z.ZodObject<{
    kind: z.ZodLiteral<"vault">;
    vaultId: z.ZodString;
    binding: z.ZodObject<{
        bindingProtocolVersion: z.ZodLiteral<1>;
        vaultId: z.ZodString;
        revision: z.ZodNumber;
        target: z.ZodNullable<z.ZodObject<{
            instanceId: z.ZodString;
            profileId: z.ZodString;
        }, z.core.$strict>>;
        updatedAt: z.ZodNumber;
        lastOperationId: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>;
    discoveryProtocolVersion: z.ZodLiteral<1>;
    bootId: z.ZodString;
    publisherId: z.ZodString;
    displayName: z.ZodString;
    origin: z.ZodString;
    capabilities: z.ZodArray<z.ZodString>;
}, z.core.$strict>;
export type DshInstanceIdentity = z.infer<typeof dshInstanceIdentitySchema>;
export type VaultIdentity = z.infer<typeof vaultIdentitySchema>;
export declare const bridgeDiscoveryRecordSchema: z.ZodUnion<readonly [z.ZodObject<{
    kind: z.ZodLiteral<"dsh">;
    instanceId: z.ZodString;
    profileId: z.ZodString;
    discoveryProtocolVersion: z.ZodLiteral<1>;
    bootId: z.ZodString;
    publisherId: z.ZodString;
    displayName: z.ZodString;
    origin: z.ZodString;
    capabilities: z.ZodArray<z.ZodString>;
    updatedAt: z.ZodNumber;
    expiresAt: z.ZodNumber;
}, z.core.$strict>, z.ZodObject<{
    kind: z.ZodLiteral<"vault">;
    vaultId: z.ZodString;
    binding: z.ZodObject<{
        bindingProtocolVersion: z.ZodLiteral<1>;
        vaultId: z.ZodString;
        revision: z.ZodNumber;
        target: z.ZodNullable<z.ZodObject<{
            instanceId: z.ZodString;
            profileId: z.ZodString;
        }, z.core.$strict>>;
        updatedAt: z.ZodNumber;
        lastOperationId: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>;
    discoveryProtocolVersion: z.ZodLiteral<1>;
    bootId: z.ZodString;
    publisherId: z.ZodString;
    displayName: z.ZodString;
    origin: z.ZodString;
    capabilities: z.ZodArray<z.ZodString>;
    updatedAt: z.ZodNumber;
    expiresAt: z.ZodNumber;
}, z.core.$strict>]>;
export type BridgeDiscoveryRecord = z.infer<typeof bridgeDiscoveryRecordSchema>;
export declare const changeVaultBindingRequestSchema: z.ZodObject<{
    operationId: z.ZodString;
    expectedRevision: z.ZodNumber;
    intent: z.ZodEnum<{
        bind: "bind";
        rebind: "rebind";
        unbind: "unbind";
    }>;
    target: z.ZodNullable<z.ZodObject<{
        instanceId: z.ZodString;
        profileId: z.ZodString;
    }, z.core.$strict>>;
    candidate: z.ZodOptional<z.ZodObject<{
        origin: z.ZodString;
        bootId: z.ZodString;
    }, z.core.$strict>>;
}, z.core.$strict>;
export type ChangeVaultBindingRequest = z.infer<typeof changeVaultBindingRequestSchema>;
export declare const boundOperationRouteSchema: z.ZodObject<{
    vaultId: z.ZodString;
    instanceId: z.ZodString;
    profileId: z.ZodString;
    bindingRevision: z.ZodNumber;
}, z.core.$strict>;
export type BoundOperationRoute = z.infer<typeof boundOperationRouteSchema>;
/** Optional capability fields preserve the original lifecycle wire version. */
export declare const bindingControlFields: {
    bindingProtocolVersion: z.ZodOptional<z.ZodLiteral<1>>;
    vaultId: z.ZodOptional<z.ZodString>;
    bindingRevision: z.ZodOptional<z.ZodNumber>;
    dshBootId: z.ZodOptional<z.ZodString>;
    profileId: z.ZodOptional<z.ZodString>;
    dshOrigin: z.ZodOptional<z.ZodString>;
};
