import { type BridgeDiscoveryRecord } from './binding.ts';
export interface DiscoveryOptions {
    directory?: string;
    now?: () => number;
    maxEntries?: number;
}
export interface DiscoveryConflict {
    kind: 'dsh' | 'vault';
    id: string;
    profileId?: string;
    publisherIds: string[];
}
export declare function getBridgeDiscoveryDirectory(env?: Record<string, string | undefined>, home?: string): string;
export declare function writeDiscoveryRecord(input: BridgeDiscoveryRecord, options?: DiscoveryOptions): Promise<void>;
export declare function readDiscoveryRecords(options?: DiscoveryOptions): Promise<{
    records: BridgeDiscoveryRecord[];
    conflicts: DiscoveryConflict[];
}>;
export declare function removeDiscoveryRecord(owner: {
    kind: 'dsh' | 'vault';
    publisherId: string;
    bootId: string;
}, options?: DiscoveryOptions): Promise<void>;
